
package chatsystemTDa2;

import java.io.Serializable;

/**
 * Class Message
 * The package "chatsystemTDa2" contains all message types predefined by group A2
 * @author Groupe A2
 * @version 1.0
 */
public abstract class Message implements Serializable
{
	private static final long serialVersionUID = 1L;
}